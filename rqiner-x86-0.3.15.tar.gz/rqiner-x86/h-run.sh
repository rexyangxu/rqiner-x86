#!/usr/bin/env bash
source h-manifest.conf


#[[ `ps aux | grep "./rqiner-x86" | grep -v grep | wc -l` != 0 ]] &&
#	echo -e "${RED}$CUSTOM_NAME miner is already running${NOCOLOR}" &&
#	exit 1

CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

if [[ -z $CUSTOM_CONFIG_FILENAME ]]; then 
	echo -e "The config file is not defined"
fi

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/hive/lib

CUSTOM_USER_CONFIG=$(< $CUSTOM_CONFIG_FILENAME) 

#echo "about to call executiable "
echo "args: $CUSTOM_USER_CONFIG"

#
# Now which miner do we chose
#
# Initialize ARCH_VALUE as empty
ARCH_VALUE=""

# Split CUSTOM_USER_CONFIG into an array
IFS=' ' read -r -a config_array <<< "$CUSTOM_USER_CONFIG"

# Iterate through array and check for -arch and its next value
for ((i = 0; i < ${#config_array[@]}; i++)); do
     echo "is:  ${config_array[$i]}"
    if [[ ${config_array[$i]} == "-arch" ]]; then
        ARCH_VALUE=${config_array[$((i + 1))]}
        break
    fi
done

# Default case if ARCH_VALUE is not set
if [ -z "$ARCH_VALUE" ]; then
    echo "No ARCH_VALUE found"
    ARCH_VALUE="none"
fi

# Case statement based on ARCH_VALUE
case "$ARCH_VALUE" in
    broadwell)
        echo "Arch value is broadwell"
        MINER="rqiner-x86-broadwell"
        ;;
    musl)
        echo "Arch value is musl"
        MINER="rqiner-x86-musl"
        ;;
    znver3)
        echo "Arch value is zen3"
        MINER="rqiner-x86-znver3"
        ;;
    znver4)
        echo "Arch value is zen4"
        MINER="rqiner-x86-znver4"
        ;;
    none)
        echo "No -arch argument set"
        # Handle the case when no -arch argument is set
        MINER="rqiner-x86"
        ;;
    *)
        echo "Unknown Arch value: $ARCH_VALUE"
        # Handle any unexpected values
        ;;
esac


#strip arch from commandline
# Remove the -arch argument and its value
CLEAN=$(echo "$CUSTOM_USER_CONFIG" | sed -E 's/-arch [^ ]+ //')
echo "args are now: $CLEAN"

echo $(date +%s) > "/tmp/miner_start_time"
/hive/miners/custom/rqiner-x86/$MINER $CLEAN  2>&1 | tee --append ${CUSTOM_LOG_BASENAME}.log

echo "Miner has exited"
